import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.component.html',
  styleUrls: ['./tab4.component.scss'],
  standalone: true,
})
export class Tab4Component  implements OnInit {

  constructor() { }

  ngOnInit() {}

}
